{- |
Module      : Tetris
Description : The Tetris game (main module)
Copyright   : (c) TDA555/DIT441, Introduction to Functional Programming
License     : BSD
Maintainer  : alexg@chalmers.se
Stability   : experimental

Authors     : Oliver Ivarsson, Omar Ahmed, Alexander Kjellberg
Lab group   : Grupp 33
-}

module Main where

import ConsoleGUI
-- import ThreepennyGUI  -- either use ConsoleGUI or ThreepennyGUI
-- import ConsoleGUI

import Shapes
import Data.Maybe (isJust)


--------------------------------------------------------------------------------
-- * The code that puts all the piece together
main :: IO ()
main = runGame tetrisGame

tetrisGame :: Game Tetris
tetrisGame = Game
  { startGame     = startTetris
  , stepGame      = stepTetris
  , drawGame      = drawTetris
  , gameInfo      = defaultGameInfo prop_Tetris
  , tickDelay     = defaultDelay
  , gameInvariant = prop_Tetris
  }

--------------------------------------------------------------------------------
-- * The various parts of the Tetris game implementation

type Pos   = (Int, Int)

-- | The state of the game consists of three parts:
data Tetris = Tetris
  { piece  :: (Pos, Shape)  -- ^ The position and shape of the falling piece
  , well   :: Shape         -- ^ The well (the playing field), where the falling pieces pile up
  , shapes :: [Shape]       -- ^ An infinite supply of random shapes
  }

-- | The size of the well
wellWidth, wellHeight :: Int
wellWidth  = 10
wellHeight = 20

wellSize :: (Int, Int)
wellSize   = (wellWidth, wellHeight)

-- | Starting position for falling pieces
startPosition :: Pos
startPosition = (wellWidth `div` 2 - 1, 0)

-- | Pos addition
add :: Pos -> Pos -> Pos
(x1, y1) `add` (x2, y2) = (x1 + x2, y1 + y2)

-- | Move the falling piece into position
place :: (Pos, Shape) -> Shape
place (v, s) = shiftShape v s

-- B4
-- | An invariant that startTetris and stepTetris should uphold
prop_Tetris :: Tetris -> Bool
prop_Tetris (Tetris piece well shapes) = prop_Shape (snd piece) && (shapeSize well == wellSize)

-- B5
-- | Add black walls around a shape
addWalls :: Shape -> Shape
addWalls s = padShapeBlack (1, 1) (shiftShapeBlack (1, 1) s)


padShapeBlack :: (Int, Int) -> Shape -> Shape
padShapeBlack (r, d) (Shape shape) = shiftLeft r (Just Black) $ shiftUp d (Just Black) (Shape shape)

shiftShapeBlack :: (Int, Int) -> Shape -> Shape
shiftShapeBlack (r, d) (Shape shape) = shiftDown d (Just Black) (shiftRight r (Just Black) (Shape shape))

--B6
-- | Visualize the current game stat. This is what the user will see
-- | when playing the game. 
drawTetris :: Tetris -> Shape
drawTetris (Tetris (v, p) w _) = addWalls (combine w (shiftShape v p))


startTetris :: [Double] -> Tetris
startTetris rs = Tetris (startPosition, piece) well supply
 where
  well         = emptyShape wellSize
  piece:supply = map shuffle rs --shuffle rs 100000

shuffle :: Double -> Shape
shuffle d  = allShapes !! (randomIndex d)

-- Converts double from 0-1 => 0-7
randomIndex :: Double -> Int
randomIndex n = floor $ n * 7.0 

-- | React to input. The function returns 'Nothing' when it's game over,
-- and @'Just' (n,t)@, when the game continues in a new state @t@.
stepTetris :: Action -> Tetris -> Maybe (Int, Tetris)
stepTetris Tick t      = tick t
stepTetris MoveDown t  = tick t
stepTetris MoveLeft t  = Just (0, movePiece (-1) t)
stepTetris MoveRight t = Just (0, movePiece 1 t)
stepTetris Rotate t    = Just (0, rotatePiece t)

-- B7
move :: Pos -> Tetris -> Tetris
move pos (Tetris (v, p) w s) = (Tetris ((add pos v), p) w s)

-- B8
tick :: Tetris -> Maybe(Int, Tetris)
tick t
  | collision (move (0,1) t) = dropNewPiece t
  | otherwise                = Just (0, (move (0,1) t))

-- C1
-- | A function to test if the falling piece has collided with the walls or something in the well:
collision :: Tetris -> Bool
collision (Tetris ((x, y), p) w s)
  | x > (9 - (fst (shapeSize p) -1) ) || (x < 0) = True
  | y > (wellHeight - (snd (shapeSize p))) = True
  | overlaps w (place ((x, y), p)) = True
  | otherwise = False

movePiece :: Int -> Tetris -> Tetris
movePiece n t
  | collision $ move (n, 0) t = t
  | otherwise = move (n, 0) t
   
-- Rotates the shape 90 degrees
rotate :: Tetris -> Tetris 
rotate (Tetris (v, p) w s) = (Tetris (v, (rotateShape p)) w s)

-- Checks whether the rotated piece
rotatePiece :: Tetris -> Tetris
rotatePiece t
  | collision (rotate t) = t
  | otherwise = rotate t


dropNewPiece :: Tetris -> Maybe (Int, Tetris)
dropNewPiece (Tetris (v, p) w s) = Just (n, ( Tetris (startPosition, (head s)) shiftedWell (tail s)))
  where
    (n, shiftedWell) = clearLines (newWell (Tetris (v, p) w s))
      where
        newWell (Tetris (v, p) w s) = (fixPiece ((Tetris (v, p) w s)))

-- Combine the falling piece with the well
fixPiece :: Tetris -> Shape
fixPiece (Tetris (v, p) w s) = combine yeah (place (v, p))
  where
    (n, yeah) = clearLines w

-- C10
clearLines :: Shape -> (Int, Shape)
clearLines s = (length complete, (Shape ( rows (emptyShape (10,(length complete))) ++ notComplete)))
 where
  notComplete = filter (not . isComplete) (rows s)
  complete = filter isComplete (rows s)

isComplete :: Row -> Bool
isComplete = all isJust